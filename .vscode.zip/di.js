



var j= JSON.parse(localStorage.getItem("webseries1"))
var k=JSON.parse(localStorage.getItem("movie1"))
var m=JSON.parse(localStorage.getItem("movie"))


    j.map(function(ele,ind){
        var div=document.createElement("div")
       var im=document.createElement("img")
       im.setAttribute("src",elem.image)
       var tit=document.createElement("h4")
       tit.textContent=elem.title
       div.append(im)
       document.querySelector("#mright1").append(div)
    })

    function p1fun(){
     //    event.preventDefault()
     document.querySelector("#mright1").textContent=""

       
    k.map(function(ele,ind){
        var div=document.createElement("div")
       var im=document.createElement("img")
       im.setAttribute("src",eleme.image)
       var tit1=document.createElement("h4")
       tit1.textContent=eleme.title
       div.append(im)
       document.querySelector("#mright1").append(div)

     })
 }

 function p2fun(){
     //    event.preventDefault()
     document.querySelector("#mright1").textContent=""
   
       
  j.map(function(ele,ind){
        var div=document.createElement("div")
       var im=document.createElement("img")
       im.setAttribute("src",eleme.image)
       var tit1=document.createElement("h4")
       tit1.textContent=eleme.title
       div.append(im)
       document.querySelector("#mright1").append(div)

     })
 }

 function p3fun(){
     //    event.preventDefault()
     document.querySelector("#mright1").textContent=""
  
       
  m.map(function(ele,ind){
        var div=document.createElement("div")
       var im=document.createElement("img")
       im.setAttribute("src",eleme.image)
       var tit1=document.createElement("h4")
       tit1.textContent=eleme.title
       div.append(im)
       document.querySelector("#mright1").append(div)

     })
 }

 function p4fun(){
     //    event.preventDefault()
     document.querySelector("#mright1").textContent=""
   
       
  j.map(function(ele,ind){
        var div=document.createElement("div")
       var im=document.createElement("img")
       im.setAttribute("src",eleme.image)
       var tit1=document.createElement("h4")
       tit1.textContent=eleme.title
       div.append(im)
       document.querySelector("#mright1").append(div)

     })
 }







 var slideIndex = 0;
 showSlides();
 
 function showSlides() {
   var i;
   var slides = document.getElementsByClassName("mySlides");
   var dots = document.getElementsByClassName("dot");
   for (i = 0; i < slides.length; i++) {
     slides[i].style.display = "none";  
   }
   slideIndex++;
   if (slideIndex > slides.length) {slideIndex = 1}    
   for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" active", "");
   }
   slides[slideIndex-1].style.display = "block";  
   dots[slideIndex-1].className += " active";
   setTimeout(showSlides, 2000); // Change image every 2 seconds
 }


 var a= JSON.parse(localStorage.getItem("webseries"))
  var b=JSON.parse(localStorage.getItem("movie"))
  var c=JSON.parse(localStorage.getItem("movie1"))
  var d=JSON.parse(localStorage.getItem("movie2"))
 



 a.map(function(elem,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         var h3=document.createElement("h3")
         h3.textContent="Exclusive Movie on Zee 5"
         div.append(im,tit)
         document.querySelector("#lowerpart").append(div)
      })
      
 b.map(function(elem,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         var h3=document.createElement("h3")
         h3.textContent="Exclusive Movie on Zee 5"
         div.append(im,tit)
         document.querySelector("#lowerpart").append(div)
      })
        
 a.map(function(elem,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         var h3=document.createElement("h3")
         h3.textContent="Exclusive Movie on Zee 5"
         div.append(im,tit)
         document.querySelector("#lowerpart").append(div)
      })
      b.map(function(elem,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         var h3=document.createElement("h3")
         h3.textContent="Exclusive Movie on Zee 5"
         div.append(im,tit)
         document.querySelector("#lowerpart").append(div)
      })

      d.map(function(elem,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         var h3=document.createElement("h3")
         h3.textContent="Exclusive Movie on Zee 5"
         div.append(im,tit)
         document.querySelector("#lowerpart").append(div)
      })


      var p= JSON.parse(localStorage.getItem("webseries"))
    var q= JSON.parse(localStorage.getItem("music"))
    var r=JSON.parse(localStorage.getItem("romantic"))
    console.log(p)
    console.log(q)
   console.log(r)
    
    p.map(function(elem,ind){
     
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",elem.image)
         var tit=document.createElement("h4")
         tit.textContent=elem.title
         div.append(im)
         document.querySelector("#mright1").append(div)
      })

      function b1fun(){
       //    event.preventDefault()
       document.querySelector("#mright").textContent=""
       console.log(b)
         
    q.map(function(eleme,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",eleme.image)
         var tit1=document.createElement("h4")
         tit1.textContent=eleme.title
         div.append(im)
         document.querySelector("#mright").append(div)

       })
   }

   function b2fun(){
       //    event.preventDefault()
       document.querySelector("#mright").textContent=""
       console.log(b)
         
    r.map(function(eleme,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",eleme.image)
         var tit1=document.createElement("h4")
         tit1.textContent=eleme.title
         div.append(im)
         document.querySelector("#mright").append(div)

       })
   }


   
   function b3fun(){
       //    event.preventDefault()
       document.querySelector("#mright").textContent=""
       console.log(c)
         
    p.map(function(eleme,ind){
          var div=document.createElement("div")
         var im=document.createElement("img")
         im.setAttribute("src",eleme.image)
         var tit1=document.createElement("h4")
         tit1.textContent=eleme.title
         div.append(im)
         document.querySelector("#mright").append(div)

       })
   }








   
function drop(){
  var show=documen.querySelector(".dropdown-content")
  show.style=("display:block")
}
   

  var slideIndex = 0;
  showSlides();
  
  function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
  }

 
  var a= JSON.parse(localStorage.getItem("webseries"))
   var b=JSON.parse(localStorage.getItem("movie"))
  
   var d=JSON.parse(localStorage.getItem("movie2"))
  
 

  a.map(function(elem,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          var h3=document.createElement("h3")
          h3.textContent="Exclusive Movie on Zee 5"
          var bt=document.createElement("button")
          bt.textContent="Watch"
          div.append(im,tit,bt)
          document.querySelector("#lowerpart").append(div)
       })
       
  b.map(function(elem,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          var h3=document.createElement("h3")
          h3.textContent="Exclusive Movie on Zee 5"
          var bt=document.createElement("button")
          bt.textContent="Watch"
          div.append(im,tit,bt)
          document.querySelector("#lowerpart").append(div)
       })
             
   
  a.map(function(elem,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
         
          var bt=document.createElement("button")
          bt.textContent="Watch"
          div.append(im,tit,bt)
          document.querySelector("#lowerpart").append(div)
       })
       b.map(function(elem,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
      
          var bt=document.createElement("button")
          bt.textContent="Watch"
          div.append(im,tit,bt)
          document.querySelector("#lowerpart").append(div)
       })

       d.map(function(elem,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          var bt=document.createElement("button")
          bt.textContent="Watch"
          div.append(im,tit,bt)
          document.querySelector("#lowerpart").append(div)
       })


       var p= JSON.parse(localStorage.getItem("webseries"))
     var q= JSON.parse(localStorage.getItem("movie"))
     var r=JSON.parse(localStorage.getItem("movie2"))
    

     
     q.map(function(elem,ind){
      
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          div.append(im)
          document.querySelector("#mright").append(div)
       })

       function b1fun(){
        //    event.preventDefault()
        document.querySelector("#mright").textContent=""
       
          
     p.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright").append(div)

        })
    }

    function b2fun(){
        //    event.preventDefault()
        document.querySelector("#mright").textContent=""
   
          
     r.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright").append(div)

        })
    }


    
    function b3fun(){
        //    event.preventDefault()
        document.querySelector("#mright").textContent=""
     
          
     q.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright").append(div)

        })
    }



      



    
    var n= JSON.parse(localStorage.getItem("movie"))
     var o= JSON.parse(localStorage.getItem("movie2"))
     var m=JSON.parse(localStorage.getItem("webseries"))
     console.log(p)
     console.log(q)
     console.log(r)

     
     n.map(function(elem,ind){
      
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          div.append(im)
          document.querySelector("#mright1").append(div)
       })

       function b1fun(){
        //    event.preventDefault()
        document.querySelector("#mright1").textContent=""
        console.log(b)
          
     o.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright1").append(div)

        })
    }

    function b2fun(){
        //    event.preventDefault()
        document.querySelector("#mright1").textContent=""
   
          
     m.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright1").append(div)

        })
    }


    
    function b3fun(){
        //    event.preventDefault()
        document.querySelector("#mright1").textContent=""
     
          
     n.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright1").append(div)

        })
    }










     
    var e= JSON.parse(localStorage.getItem("webseries"))
     var f= JSON.parse(localStorage.getItem("movie"))
     var g=JSON.parse(localStorage.getItem("movie2"))
    

     
     e.map(function(elem,ind){
      
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          div.append(im)
          document.querySelector("#mright2").append(div)
       })

       function b1fun(){
        //    event.preventDefault()
        document.querySelector("#mright2").textContent=""
        console.log(b)
          
     f.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright2").append(div)

        })
    }

    function b2fun(){
        //    event.preventDefault()
        document.querySelector("#mright2").textContent=""
   
          
     g.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright2").append(div)

        })
    }


    
    function b3fun(){
        //    event.preventDefault()
        document.querySelector("#mright2").textContent=""
     
          
     e.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright2").append(div)

        })
    }









        
    var t= JSON.parse(localStorage.getItem("movie2"))
     var u= JSON.parse(localStorage.getItem("webseries"))
     var v=JSON.parse(localStorage.getItem("movie"))
    

     
     t.map(function(elem,ind){
      
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",elem.image)
          var tit=document.createElement("h4")
          tit.textContent=elem.title
          div.append(im)
          document.querySelector("#mright3").append(div)
       })

       function b1fun(){
        //    event.preventDefault()
        document.querySelector("#mright3").textContent=""
        console.log(b)
          
     u.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright3").append(div)

        })
    }

    function b2fun(){
        //    event.preventDefault()
        document.querySelector("#mright3").textContent=""
   
          
     v.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright3").append(div)

        })
    }


    
    function b3fun(){
        //    event.preventDefault()
        document.querySelector("#mright3").textContent=""
     
          
     t.map(function(eleme,ind){
           var div=document.createElement("div")
          var im=document.createElement("img")
          im.setAttribute("src",eleme.image)
          var tit1=document.createElement("h4")
          tit1.textContent=eleme.title
          div.append(im)
          document.querySelector("#mright3").append(div)

        })
    }



    function openNav() {
  document.getElementById("myMenu").style.width = "300px";
}

function closeNav() {
  document.getElementById("myMenu").style.width = "0";

}

/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}